package tarun.base;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import tarun.model.EmployeeModel;
import tarun.base.EmpDAOImpl;  

@Controller
public class Controller1 {

    @Autowired
    private EmpDAOImpl em; 

    @GetMapping("/home")
    public ModelAndView home(ModelAndView mv) {
        List<EmployeeModel> l = em.getAllEmployees();
        mv.addObject("result", l);
        mv.setViewName("home");
        return mv;
    }
}

//package tarun.base;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.servlet.ModelAndView;
//
//import tarun.model.EmployeeModel;
//
//@Controller
//public class Controller1 {
//	
//	
//	
//	EmpDAOImpl em; 
//
////	public EmpDAOImpl getEm() {
////		return em;
////	}
////	@Autowired
////	public void setEm(EmpDAOImpl em) {
////		this.em = em;
////	}
//
//	@GetMapping("/home")
//	public ModelAndView home(ModelAndView mv)
//	{
//		List<EmployeeModel> l= em.getAllEmployees();
//		mv.addObject("result",l);
//		mv.setViewName("home");
//		return mv;
//		
//	}
//	
//	
////	@GetMapping("/OperationsController")
////	public ModelAndView OperationsController(ModelAndView mv)
////	{
////		List<EmployeeModel> l= em.getAllEmployees();
////		mv.addObject("result",l);
////		mv.setViewName("home");
////		return mv;
////		
////	}
//	
//}


