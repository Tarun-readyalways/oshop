package tarun.base;

import java.util.List;

import tarun.model.EmployeeModel;

public interface EmpDAO {
	//EmployeeModel getEmployeeByNo(Integer eno);

	List<EmployeeModel> getAllEmployees();

	//boolean deleteEmployee(EmployeeModel e);

	//boolean updateEmployee(EmployeeModel e);

	//boolean createEmployee(EmployeeModel e);


}
