package tarun.base;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

import javax.sql.DataSource;

import tarun.model.EmployeeModel;

@Repository 
public class EmpDAOImpl implements EmpDAO{
	
	JdbcTemplate jdbcTemplate;

	//private final String SQL_FIND_EmployeeModel = "select * from emp where empno = ?";
	//private final String SQL_DELETE_EmployeeModel = "delete from emp where empno = ?";
	//private final String SQL_UPDATE_EmployeeModel = "update emp set ename = ?, job = ?, sal  = ?, deptno  = ? where empno = ?";
	private final String SQL_GET_ALL = "select * from empjt";
	//private final String SQL_INSERT_EmployeeModel = "insert into emp(empno, ename, job, sal,deptno) values(?,?,?,?,?)";

	@Autowired
	public EmpDAOImpl(DataSource dataSource) {
		
		jdbcTemplate = new JdbcTemplate(dataSource);
	}


	


//	@Override
//	public EmployeeModel getEmployeeByNo(Integer eno) {
//		return jdbcTemplate.queryForObject(SQL_FIND_EmployeeModel, new Object[] { eno }, new Mapper());
//
//		
//	}


	@Override
	public List<EmployeeModel> getAllEmployees() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_ALL, new Mapper());
	}


//	@Override
//	public boolean deleteEmployee(EmployeeModel e) {
//		return jdbcTemplate.update(SQL_DELETE_EmployeeModel, e.getEmpNo()) > 0;
//	}
//
//	
//
//
//	@Override
//	public boolean updateEmployee(EmployeeModel e) {
//		return jdbcTemplate.update(SQL_UPDATE_EmployeeModel, e.getEName(), e.getJob(), e.getSalary(),e.getDeptNo(),
//				e.getEmpNo()) > 0;
//
//	}
//
//
//	@Override
//	public boolean createEmployee(EmployeeModel e) {
//		// TODO Auto-generated method stub
//		return jdbcTemplate.update(SQL_INSERT_EmployeeModel, e.getEmpNo(), e.getEName(), e.getJob(),
//				e.getSalary(),e.getDeptNo()) > 0;
//
//	}





	
	}


	

