package tarun.base;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import tarun.model.EmployeeModel;

public class Mapper implements RowMapper<EmployeeModel> {

	@Override
	public EmployeeModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		EmployeeModel emp = new EmployeeModel();
		emp.setEmpNo(rs.getInt("empno"));
		emp.setEName(rs.getString("ename"));
		emp.setJob(rs.getString("job"));
		emp.setSalary(rs.getDouble("sal"));
		emp.setDeptNo(rs.getInt("deptno"));
		return emp;

	}

}
