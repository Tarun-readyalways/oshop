package form;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("username");
		String pass = request.getParameter("password");

		HttpSession session = request.getSession();
		session.setAttribute("username", uname);
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			PreparedStatement ps = con.prepareStatement("select username,password from sz_users");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String u = rs.getString(1);
				String p = rs.getString(2);
				if (uname.equals(u) && pass.equals(p)) {
					System.out.println("login success");
					// request.getRequestDispatcher("Welcome1").include(request, response);\
					response.sendRedirect("dashboard.html");

				}
			}

		} catch (Exception e2) {
			System.out.println(e2);
		}
	}

}
