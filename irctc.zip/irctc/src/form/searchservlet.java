package form;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/searchservlet")
public class searchservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ResultSet rs = null;
		Connection conn = null;

		String fr = request.getParameter("fromt");
		String ts = request.getParameter("tot");

		central.from_station = fr;
		central.to_station = ts;

		List<JSONObject> trainslist = new ArrayList<>();

		HttpSession session = request.getSession();
		session.setAttribute("from", fr);
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			PreparedStatement ps = con.prepareStatement("select * from sz_trains where froms=? and tos=?");
			ps.setString(1, fr);
			ps.setString(2, ts);
			rs = ps.executeQuery();
			while (rs.next()) {
				// System.out.println(rs.getString(1));
				// System.out.println(rs.getString(4));
				JSONObject train = new JSONObject();
				train.put("id", rs.getString(1));
				train.put("trainname", rs.getString(4));
				trainslist.add(train);

			}
			JSONArray jsonArray = new JSONArray(trainslist);
			// System.out.println("JSON Array: " + jsonArray.toString());
			response.setContentType("application/json");
			PrintWriter out = response.getWriter();
			out.write(jsonArray.toString());
			out.flush();

		} catch (

		Exception e) {
			e.printStackTrace();

		}
		{
			// Close all resources
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}