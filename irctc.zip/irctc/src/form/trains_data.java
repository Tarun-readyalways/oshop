package form;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/trains_data")
public class trains_data extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// System.out.println("dfsd");
		Connection conn = null;
		ResultSet rs = null;
		List<JSONObject> stationList = new ArrayList<>();

		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			PreparedStatement stmt = conn.prepareStatement("select stn_code,stn_name from sz_railway");
			rs = stmt.executeQuery();
			// ======================================//
			while (rs.next()) {
				// System.out.println(rs.getString(1));
				JSONObject station = new JSONObject();
				station.put("stn_code", rs.getString(1));
				station.put("stn_name", rs.getString(2));
				stationList.add(station);
			}
			JSONArray jsonArray = new JSONArray(stationList);

			// System.out.println("JSON Array: " + jsonArray.toString());
			response.setContentType("application/json");
			PrintWriter out = response.getWriter();
			out.write(jsonArray.toString());
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			// Close all resources
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}